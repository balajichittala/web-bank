


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/admincontact")
public class admincontact extends HttpServlet {
	Connection con;
	
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
        
		pw.println("<strong> <a href=http://localhost:8090/webank/WelcomeServlet>Home</a></strong>\t\t");
		pw.println("<strong><a href=LogOut>Log out</a></strong><br /><br />");
		
		String coct=request.getParameter("contact");
		
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
		System.out.println("Database connection established successfully in retrieviing complaints from Database");
		
		PreparedStatement pstmt=con.prepareStatement("select * from contact");
		
		ResultSet rs=pstmt.executeQuery();
	     while(rs.next()){
	    	 
	    	 pw.print("<html><head><body>");
	    	 pw.print("<h1>contact details </h1>");
	    	 pw.print("<h2>"+ "Name"+ " "+ "email"+ " "+ "message" +" </h3>");
	    	 pw.print(rs.getString(1)+ "   "+ rs.getString(2)+ "   "+ rs.getString(3));
	    	 pw.print("</body></head></html>");
	     }
		}
		catch(Exception e){
			System.err.println(e);
		}
	}

	
}
