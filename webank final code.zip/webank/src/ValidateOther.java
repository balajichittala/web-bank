

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ValidateOther
 */
@WebServlet("/ValidateOther")
public class ValidateOther extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
          response.setContentType("text/html");
		try {
		    Class.forName("oracle.jdbc.driver.OracleDriver");
		   Connection connection =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
		   String s2=request.getParameter("pword");
			
			PreparedStatement pstmt=connection.prepareStatement("select * from customer where pword=?");
			pstmt.setString(2, s2);
	
		  ResultSet rs=pstmt.executeQuery();
		  PrintWriter pw=response.getWriter();
		  if(rs.next()){
			((HttpServletResponse) response).sendRedirect("Ftother.html");
		  }
		  else{
			  pw.println("invalid password");
			  RequestDispatcher rd=request.getRequestDispatcher("validateother.html");
			  rd.include(request, response);
		  }
		   
		}
		catch(Exception e){
			
		}
	}
       
}
