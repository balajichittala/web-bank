
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import bank.CusGetSet;

@WebServlet("/RegisterServ")
public class RegisterServ extends HttpServlet {



	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		  try {
		    String s1=request.getParameter("fname");
	        String s2=request.getParameter("lname");
	        String s3=request.getParameter("bdate");
	        String s4=request.getParameter("userid");
	        String s5=request.getParameter("pword");
	        String s6=request.getParameter("actno");
	        String s7=request.getParameter("gen");
	        String s8=request.getParameter("bal");
	        
	        System.out.println(s1+s2+s3+s4+s5+s6+s7+s8);
	   CusGetSet cgs=new CusGetSet();
	   cgs.setFname(s1);
	   cgs.setLname(s2);
	   cgs.setBdate(s3);
	   cgs.setUserid(s4);
	   cgs.setPword(s5);
	   cgs.setActno(s6);
	   cgs.setGender(s7);
	   cgs.setBal(s8);

      
	 
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		
		PreparedStatement pstmt=con.prepareStatement("insert into customer values(?,?,?,?,?,?,?,?)");
	
		
	       pstmt.setString(1,cgs.getFname());
	       pstmt.setString(2,cgs.getLname());
	       pstmt.setString(3,cgs.getBdate());
	       pstmt.setString(4,cgs.getUserid());
	       pstmt.setString(5,cgs.getPword());
	       pstmt.setString(6,cgs.getActno());
	       pstmt.setString(7,cgs.getGender());
	       pstmt.setString(8,cgs.getBal());
     
         int result=pstmt.executeUpdate();
         if(result>0){
             //con.commit();
           pw.println("datasaved successfully");
           RequestDispatcher rd=request.getRequestDispatcher("login.html");
           rd.include(request, response);
         }
         else{
             response.sendRedirect("register.html");

         }    
 	  
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   
	}
	 
}
