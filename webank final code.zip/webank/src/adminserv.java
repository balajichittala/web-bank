
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



@WebServlet("/adminserv")
public class adminserv extends HttpServlet {


protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType("text/html");
    PrintWriter out=response.getWriter();
    out.println("<strong> <a href=http://localhost:8090/webank/adminlist.html>Home</a></strong>\t\t");	
     
    try{
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
    String str1=request.getParameter("name");
    String str2=request.getParameter("password");
    
    PreparedStatement pstmt=con.prepareStatement("select * from admin where name=? and password=?");
        
    pstmt.setString(1, str1);
    pstmt.setString(2, str2);
    
    ResultSet rs=pstmt.executeQuery();
    
    if(rs.next()){
        HttpSession hs=request.getSession();
        hs.setAttribute("name",str1);
        hs.setAttribute("password", str2);
        
        out.print("you are successfully logedin");
        response.sendRedirect("adminlist.html");
           
    }
    else{
        out.print("invalid login");
        RequestDispatcher rd=request.getRequestDispatcher("adminlogin.html");
        rd.include(request, response);
    }
    
} 
catch (ClassNotFoundException e) {
    
    e.printStackTrace();
} 
catch (SQLException e) {
  
    e.printStackTrace();
}
}




}







