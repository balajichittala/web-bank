import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Contact")
public class Contact extends HttpServlet {
	Connection con;
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		pw.println("<title>Contact us</title>");
		pw.println("<link rel='icon' href='https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSobgGygd2MoDxxn1PKrU9av2Y8ZLAh6imiXg&usqp=CAU' type='image/gif' sizes='16x16'>");
		try{
			String s1=request.getParameter("name");
		    String s2=request.getParameter("email");
		    String s3=request.getParameter("message");
		    
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("Database connection established successfully in retrieviing complaints from Database");

		    PreparedStatement pstmt=con.prepareStatement("insert into contact values(?,?,?)");
		    
		    pstmt.setString(1,s1);
		    pstmt.setString(2,s2);
		    pstmt.setString(3,s3);
			pstmt.executeUpdate();
		    con.commit();
		    
		    response.sendRedirect("bankhomepage.html");
		}
		catch(Exception e){
			System.err.println(e);
	}
 }
}
