

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/FTOtherBank")
public class FTOtherBank extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FTOtherBank() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
    
    Connection con;
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		

		super.init(config);
			
try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("Database connection established successfully in Funds transfer to Other bank servlet");
			
		}
		
		catch(Exception e){
			System.err.println(e);
			
		}


	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	
		String s1=request.getParameter("actno");
		String s2=request.getParameter("amt");
		String s3=request.getParameter("ifsc");
		String s4=request.getParameter("bank");
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<title>Fund Transfer</title>");
		pw.println("<link rel='icon' href='https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSobgGygd2MoDxxn1PKrU9av2Y8ZLAh6imiXg&usqp=CAU' type='image/gif' sizes='16x16'>");
		
		pw.println("<body background='https://camo.githubusercontent.com/161566499195bcae38b872e7b34ec18e9ff52180/687474703a2f2f692e696d6775722e636f6d2f744735644948782e6a7067'>");
		pw.println("<strong><a href=WelcomeServlet>Home</a></strong> ");
		pw.println("<strong><a href=LogOut>Log out</a></strong><br />");
		
		pw.println("Recipient Account number is : "+s1);
		pw.println("<br />Balance to be transferred is : "+s2);
		Cookie c[]=request.getCookies();
			
		PreparedStatement pstmt;
		
        ResultSet rs1;
		
		long tranid=0;
		String remarks=" ",transtatus=" ",trandesc="Funds Transfer to "+ s4 +" Bank",actno=c[2].getValue();
		
		try {
			pstmt =con.prepareStatement("select count(*) from transaction");
			rs1=pstmt.executeQuery();
			System.out.println(rs1);
			rs1.next();
			tranid=rs1.getLong(1);
			
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
		
		
			if(Long.parseLong(c[3].getValue())<Long.parseLong(s2)){
			
			pw.println("<br />Funds transfer can not be initiated as available balance is less than the to be transferred amount");
			remarks="Funds transfer can not be initiated as available balance is less than the to be transferred amount";
			transtatus="fail";
		}
		
		else{
			
			
			
			try {
				
				long newBal= Long.parseLong(c[3].getValue())-Long.parseLong(s2);
				
				
				pstmt = con.prepareStatement("update customer set balance=? where act_no=?");
							
				pstmt.setLong(1, newBal);
				pstmt.setString(2,actno);
				
				pstmt.executeUpdate();
				
				pw.println("<br /> Funds Rs "+s2+" transfer initiated to the account number "+s1);
				
				pw.println("<br />Available balance in the account is Rs "+newBal);
								
				remarks="Funds transferred successfully";
				transtatus="pass";
			} 
			
			catch (Exception e) {
			
				e.printStackTrace();
			}
			
			
			
			System.out.println("New balance is updated successfully in database");
			
		}
		
		try {
		pstmt=con.prepareStatement("insert into transaction(tranid,act_no,tran_desc,tran_status,remarks,ifsc) values(?,?,?,?,?,?)");
		
		pstmt.setLong(1,tranid);
		pstmt.setString(2, actno);
		pstmt.setString(3, trandesc);
		pstmt.setString(4, transtatus);
		pstmt.setString(5, remarks);
		pstmt.setString(6, s3);
		
		pstmt.executeUpdate();
		
		System.out.println("Transaction table updated successfully");
	
		}
		catch(Exception e){
			
		}
	}

}
