
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ViewTrans extends HttpServlet {

    
    Connection con;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PreparedStatement pstmt;
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<body background='https://camo.githubusercontent.com/161566499195bcae38b872e7b34ec18e9ff52180/687474703a2f2f692e696d6775722e636f6d2f744735644948782e6a7067'>");		
        pw.println("<strong><a href=http://localhost:8090/webank/WelcomeServlet>Home</a></strong>\t\t");
		
		pw.println("<strong><a href=LogOut>Log out</a></strong><br /><br />");
		
		pw.println("<h4>Details of Transactions :</h4>");
		
		Cookie c[]=request.getCookies();
		
		
		try{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("Database connection established successfully");
			
			pstmt=con.prepareStatement("select * from transaction where act_no=?",ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
			pstmt.setString(1, c[2].getValue());
			
			ResultSet rs=pstmt.executeQuery();
			
		
			if(rs.absolute(1))
			{

						ResultSetMetaData rm=rs.getMetaData();
						
						int colcnt=rm.getColumnCount();
						
						for(int i=1;i<=colcnt;i++){
				
							 pw.print("<strong>" +rm.getColumnName(i).toLowerCase() +"</strong>");
							
							 
						}
						
						rs.first();
						do {
							pw.println("<br />");
							
							for(int i=1;i<=colcnt;i++){
								
								pw.print(rs.getString(i)+"   .    ");
								
							} 
							
										
						} while(rs.next());
			
			}
			
			else{
				pw.println("There are no Transactions happened in this account");
			}
		}
		
		catch(Exception e){
			System.err.println(e);
		}

	}

}
